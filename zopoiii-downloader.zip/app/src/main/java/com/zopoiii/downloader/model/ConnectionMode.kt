package com.zopoiii.downloader.model

enum class ConnectionMode(val displayName: String, val connectionCount: Int) {
    AUTO("AUTO", 0),
    ONE("1", 1),
    TWO("2", 2),
    FOUR("4", 4),
    EIGHT("8", 8),
    SIXTEEN("16", 16);

    companion object {
        fun fromInt(count: Int): ConnectionMode = when (count) {
            0 -> AUTO
            1 -> ONE
            2 -> TWO
            4 -> FOUR
            8 -> EIGHT
            16 -> SIXTEEN
            else -> AUTO
        }
    }
}
