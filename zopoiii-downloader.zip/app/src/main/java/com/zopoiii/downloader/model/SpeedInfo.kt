package com.zopoiii.downloader.model

data class SpeedInfo(
    val currentBytesPerSec: Long = 0L,
    val averageBytesPerSec: Long = 0L,
    val etaSeconds: Long = -1L
) {
    val formattedCurrentSpeed: String
        get() = formatSpeed(currentBytesPerSec)

    val formattedAverageSpeed: String
        get() = formatSpeed(averageBytesPerSec)

    val formattedEta: String
        get() = formatEta(etaSeconds)

    companion object {
        fun formatSpeed(bytesPerSec: Long): String {
            if (bytesPerSec <= 0L) return "0 B/s"
            val b = bytesPerSec.toDouble()
            val kb = b / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0

            return when {
                gb >= 1.0 -> String.format(java.util.Locale.US, "%.2f GB/s", gb)
                mb >= 1.0 -> String.format(java.util.Locale.US, "%.1f MB/s", mb)
                kb >= 1.0 -> String.format(java.util.Locale.US, "%.1f KB/s", kb)
                else -> "${bytesPerSec} B/s"
            }
        }

        fun formatBytes(bytes: Long): String {
            if (bytes < 0) return "Unknown"
            if (bytes == 0L) return "0 B"
            val b = bytes.toDouble()
            val kb = b / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            val tb = gb / 1024.0

            return when {
                tb >= 1.0 -> String.format(java.util.Locale.US, "%.2f TB", tb)
                gb >= 1.0 -> String.format(java.util.Locale.US, "%.2f GB", gb)
                mb >= 1.0 -> String.format(java.util.Locale.US, "%.1f MB", mb)
                kb >= 1.0 -> String.format(java.util.Locale.US, "%.1f KB", kb)
                else -> "$bytes B"
            }
        }

        fun formatEta(seconds: Long): String {
            if (seconds < 0) return "--:--"
            val hrs = seconds / 3600
            val mins = (seconds % 3600) / 60
            val secs = seconds % 60
            return if (hrs > 0) {
                String.format(java.util.Locale.US, "%02d:%02d:%02d", hrs, mins, secs)
            } else {
                String.format(java.util.Locale.US, "%02d:%02d", mins, secs)
            }
        }
    }
}
