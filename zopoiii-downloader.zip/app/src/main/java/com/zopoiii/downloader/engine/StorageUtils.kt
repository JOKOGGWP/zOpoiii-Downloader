package com.zopoiii.downloader.engine

import android.content.Context
import android.os.Environment
import android.os.StatFs
import java.io.File

object StorageUtils {

    fun getDefaultDownloadDirectory(context: Context): File {
        val publicDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val targetDir = File(publicDir, "zOpoiii Downloader")
        if (!targetDir.exists()) {
            val created = targetDir.mkdirs()
            if (!created && !targetDir.exists()) {
                // Fallback to app specific external files dir or files dir
                val appExternal = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                if (appExternal != null && (appExternal.exists() || appExternal.mkdirs())) {
                    return File(appExternal, "zOpoiii Downloader").apply { mkdirs() }
                }
                val internal = File(context.filesDir, "downloads")
                internal.mkdirs()
                return internal
            }
        }
        return targetDir
    }

    fun getAvailableStorageBytes(directory: File): Long {
        return try {
            val target = if (directory.exists()) directory else directory.parentFile ?: directory
            val statFs = StatFs(target.absolutePath)
            statFs.availableBlocksLong * statFs.blockSizeLong
        } catch (_: Exception) {
            -1L
        }
    }

    fun hasEnoughStorage(directory: File, requiredBytes: Long): Boolean {
        if (requiredBytes <= 0L) return true
        val available = getAvailableStorageBytes(directory)
        if (available < 0L) return true // Cannot determine, allow
        // Keep a small buffer (e.g. 20MB)
        val safetyBuffer = 20L * 1024L * 1024L
        return available > (requiredBytes + safetyBuffer)
    }
}
