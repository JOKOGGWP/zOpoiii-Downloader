package com.zopoiii.downloader.ui.theme

import androidx.compose.ui.graphics.Color

// Light Scheme
val PrimaryLight = Color(0xFF00668B)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFC3E8FF)
val OnPrimaryContainerLight = Color(0xFF001E2E)

val SecondaryLight = Color(0xFF4E616D)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFD1E5F4)
val OnSecondaryContainerLight = Color(0xFF0A1E28)

val TertiaryLight = Color(0xFF605A7D)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFE6DEFF)
val OnTertiaryContainerLight = Color(0xFF1D1736)

val BackgroundLight = Color(0xFFF7F9FC)
val OnBackgroundLight = Color(0xFF191C1E)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF191C1E)
val SurfaceVariantLight = Color(0xFFDCE3E9)
val OnSurfaceVariantLight = Color(0xFF40484D)
val OutlineLight = Color(0xFF70787E)

// Dark Scheme - Sleek Navy / Cyber Cyan Accent
val PrimaryDark = Color(0xFF00E5FF)
val OnPrimaryDark = Color(0xFF003549)
val PrimaryContainerDark = Color(0xFF004D69)
val OnPrimaryContainerDark = Color(0xFFC3E8FF)

val SecondaryDark = Color(0xFF80D8FF)
val OnSecondaryDark = Color(0xFF00344D)
val SecondaryContainerDark = Color(0xFF004C6E)
val OnSecondaryContainerDark = Color(0xFFBBE9FF)

val TertiaryDark = Color(0xFFB388FF)
val OnTertiaryDark = Color(0xFF2C1656)
val TertiaryContainerDark = Color(0xFF432E6E)
val OnTertiaryContainerDark = Color(0xFFE8DDFF)

val BackgroundDark = Color(0xFF0B1118)
val OnBackgroundDark = Color(0xFFE1E3E6)
val SurfaceDark = Color(0xFF111822)
val OnSurfaceDark = Color(0xFFE1E3E6)
val SurfaceVariantDark = Color(0xFF1E2734)
val OnSurfaceVariantDark = Color(0xFFC0C8D0)
val OutlineDark = Color(0xFF3B4856)

// Status Colors
val StatusActive = Color(0xFF00E5FF)
val StatusSuccess = Color(0xFF00E676)
val StatusPaused = Color(0xFFFFB300)
val StatusError = Color(0xFFFF5252)
val StatusQueued = Color(0xFFB0BEC5)
