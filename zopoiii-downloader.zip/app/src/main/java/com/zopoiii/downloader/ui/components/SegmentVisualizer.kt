package com.zopoiii.downloader.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zopoiii.downloader.data.local.SegmentEntity
import com.zopoiii.downloader.model.SegmentStatus
import com.zopoiii.downloader.model.SpeedInfo
import com.zopoiii.downloader.ui.theme.StatusActive
import com.zopoiii.downloader.ui.theme.StatusError
import com.zopoiii.downloader.ui.theme.StatusSuccess

@Composable
fun SegmentVisualizer(
    segments: List<SegmentEntity>,
    modifier: Modifier = Modifier
) {
    if (segments.isEmpty()) return

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Connections & Segments (${segments.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            val completedCount = segments.count { it.status == SegmentStatus.COMPLETED }
            Text(
                text = "$completedCount/${segments.size} Done",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
        }

        segments.forEach { segment ->
            SegmentRow(segment = segment)
        }
    }
}

@Composable
private fun SegmentRow(segment: SegmentEntity) {
    val statusColor = when (segment.status) {
        SegmentStatus.COMPLETED -> StatusSuccess
        SegmentStatus.DOWNLOADING -> StatusActive
        SegmentStatus.FAILED -> StatusError
        SegmentStatus.PENDING -> MaterialTheme.colorScheme.outline
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Connection #${segment.segmentIndex + 1}",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "${segment.progressPercent.toInt()}% (${SpeedInfo.formatBytes(segment.downloadedBytes)} / ${SpeedInfo.formatBytes(segment.totalSegmentBytes)})",
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        LinearProgressIndicator(
            progress = { (segment.progressPercent / 100f).coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = statusColor,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}
