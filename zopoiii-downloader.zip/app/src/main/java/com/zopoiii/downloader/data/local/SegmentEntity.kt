package com.zopoiii.downloader.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.zopoiii.downloader.model.SegmentStatus

@Entity(
    tableName = "segments",
    foreignKeys = [
        ForeignKey(
            entity = DownloadEntity::class,
            parentColumns = ["id"],
            childColumns = ["downloadId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["downloadId"])]
)
data class SegmentEntity(
    @PrimaryKey(autoGenerate = true)
    val segmentId: Long = 0L,
    val downloadId: Long,
    val segmentIndex: Int,
    val startByte: Long,
    val endByte: Long,
    val downloadedBytes: Long = 0L,
    val status: SegmentStatus = SegmentStatus.PENDING
) {
    val totalSegmentBytes: Long
        get() = (endByte - startByte) + 1L

    val progressPercent: Float
        get() = if (totalSegmentBytes > 0L) {
            ((downloadedBytes.toDouble() / totalSegmentBytes.toDouble()) * 100).toFloat().coerceIn(0f, 100f)
        } else 0f
}
