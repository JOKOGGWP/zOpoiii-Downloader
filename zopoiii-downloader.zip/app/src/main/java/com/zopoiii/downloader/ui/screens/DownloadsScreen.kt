package com.zopoiii.downloader.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.zopoiii.downloader.data.local.DownloadEntity
import com.zopoiii.downloader.model.DownloadStatus
import com.zopoiii.downloader.model.SpeedInfo
import com.zopoiii.downloader.ui.MainViewModel
import com.zopoiii.downloader.ui.components.DownloadCard
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadsScreen(
    viewModel: MainViewModel,
    onNavigateToDetail: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val allDownloads by viewModel.allDownloads.collectAsState()
    val speeds by viewModel.speeds.collectAsState()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("Active", "Queue", "Completed", "Failed")

    var itemToDelete by remember { mutableStateOf<DownloadEntity?>(null) }
    var alsoDeleteFile by remember { mutableStateOf(false) }

    val filteredList = when (selectedTabIndex) {
        0 -> allDownloads.filter { it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.PAUSED }
        1 -> allDownloads.filter { it.status == DownloadStatus.QUEUED }
        2 -> allDownloads.filter { it.status == DownloadStatus.COMPLETED }
        3 -> allDownloads.filter { it.status == DownloadStatus.FAILED || it.status == DownloadStatus.CANCELLED }
        else -> allDownloads
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Downloads",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        PrimaryTabRow(selectedTabIndex = selectedTabIndex) {
            tabs.forEachIndexed { index, title ->
                val count = when (index) {
                    0 -> allDownloads.count { it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.PAUSED }
                    1 -> allDownloads.count { it.status == DownloadStatus.QUEUED }
                    2 -> allDownloads.count { it.status == DownloadStatus.COMPLETED }
                    3 -> allDownloads.count { it.status == DownloadStatus.FAILED || it.status == DownloadStatus.CANCELLED }
                    else -> 0
                }
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = { Text("$title ($count)") }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (filteredList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No ${tabs[selectedTabIndex].lowercase()} downloads",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredList, key = { it.id }) { item ->
                    DownloadCard(
                        download = item,
                        speedInfo = speeds[item.id] ?: SpeedInfo(),
                        onCardClick = { onNavigateToDetail(item.id) },
                        onPauseClick = { viewModel.pauseDownload(item.id) },
                        onResumeClick = { viewModel.resumeDownload(item.id) },
                        onCancelClick = { viewModel.cancelDownload(item.id) },
                        onRetryClick = { viewModel.retryDownload(item.id) },
                        onOpenFileClick = { openDownloadedFile(context, item) },
                        onShareClick = { shareDownloadedFile(context, item) },
                        onDeleteClick = {
                            itemToDelete = item
                            alsoDeleteFile = false
                        }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }

    // Delete confirmation dialog
    if (itemToDelete != null) {
        val target = itemToDelete!!
        AlertDialog(
            onDismissRequest = { itemToDelete = null },
            title = { Text("Delete Download") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Remove \"${target.filename}\" from download history?")
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { alsoDeleteFile = !alsoDeleteFile }
                    ) {
                        Checkbox(
                            checked = alsoDeleteFile,
                            onCheckedChange = { alsoDeleteFile = it }
                        )
                        Text(
                            text = "Also delete file from storage",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteDownload(target.id, alsoDeleteFile)
                        itemToDelete = null
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

private fun openDownloadedFile(context: Context, download: DownloadEntity) {
    val file = File(download.destinationPath)
    if (!file.exists()) {
        Toast.makeText(context, "File does not exist on storage", Toast.LENGTH_SHORT).show()
        return
    }

    try {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, download.mimeType ?: "*/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Cannot open file: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

private fun shareDownloadedFile(context: Context, download: DownloadEntity) {
    val file = File(download.destinationPath)
    if (!file.exists()) {
        Toast.makeText(context, "File does not exist on storage", Toast.LENGTH_SHORT).show()
        return
    }

    try {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = download.mimeType ?: "*/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share file"))
    } catch (e: Exception) {
        Toast.makeText(context, "Cannot share file: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
