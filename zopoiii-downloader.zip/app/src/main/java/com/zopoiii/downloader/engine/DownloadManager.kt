package com.zopoiii.downloader.engine

import android.content.Context
import android.util.Log
import com.zopoiii.downloader.data.local.AppDatabase
import com.zopoiii.downloader.data.local.DownloadEntity
import com.zopoiii.downloader.data.preferences.SettingsDataStore
import com.zopoiii.downloader.model.DownloadStatus
import com.zopoiii.downloader.model.FileMetadata
import com.zopoiii.downloader.model.SpeedInfo
import com.zopoiii.downloader.service.DownloadForegroundService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

class DownloadManager private constructor(private val context: Context) {

    private val TAG = "DownloadManager"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val db = AppDatabase.getInstance(context)
    private val downloadDao = db.downloadDao()
    private val segmentDao = db.segmentDao()
    private val settingsDataStore = SettingsDataStore(context)

    private val rateLimiter = RateLimiter(0L)
    private val activeTasks = ConcurrentHashMap<Long, DownloadTask>()

    private val _speeds = MutableStateFlow<Map<Long, SpeedInfo>>(emptyMap())
    val speeds: StateFlow<Map<Long, SpeedInfo>> = _speeds.asStateFlow()

    init {
        // Observe settings changes for speed limit
        scope.launch {
            settingsDataStore.settingsFlow.collect { settings ->
                rateLimiter.maxBytesPerSecond = settings.speedLimitBytesPerSec
            }
        }
    }

    suspend fun recoverAfterRestart() = withContext(Dispatchers.IO) {
        // Crash recovery: mark active downloads that were interrupted as PAUSED
        val active = downloadDao.getActiveDownloads()
        for (download in active) {
            Log.d(TAG, "Recovering interrupted download: ${download.filename}")
            downloadDao.updateStatus(download.id, DownloadStatus.PAUSED, "Interrupted by system or restart")
        }
    }

    suspend fun enqueueDownload(
        metadata: FileMetadata,
        customFilename: String? = null
    ): Long = withContext(Dispatchers.IO) {
        val defaultDir = StorageUtils.getDefaultDownloadDirectory(context)
        val desiredFilename = customFilename?.takeIf { it.isNotBlank() } ?: metadata.filename
        val resolvedFilename = FilenameUtils.resolveDuplicateFilename(defaultDir, desiredFilename)
        val destinationPath = File(defaultDir, resolvedFilename).absolutePath

        val settings = settingsDataStore.settingsFlow.first()
        val connectionCount = SmartConnectionManager.calculateInitialConnections(
            isRangeSupported = metadata.isRangeSupported,
            totalBytes = metadata.totalBytes,
            preferredMode = settings.connectionMode,
            maxConfiguredConnections = settings.maxConnections
        )

        val entity = DownloadEntity(
            url = metadata.resolvedUrl,
            filename = resolvedFilename,
            destinationPath = destinationPath,
            totalBytes = metadata.totalBytes,
            downloadedBytes = 0L,
            status = DownloadStatus.QUEUED,
            etag = metadata.etag,
            lastModified = metadata.lastModified,
            acceptRanges = metadata.isRangeSupported,
            connectionCount = connectionCount,
            mimeType = metadata.contentType
        )

        val id = downloadDao.insertDownload(entity)
        checkAndProcessQueue()
        id
    }

    fun startOrResume(id: Long) {
        scope.launch {
            val entity = downloadDao.getDownloadById(id) ?: return@launch
            if (activeTasks.containsKey(id)) {
                return@launch
            }

            val activeCount = activeTasks.size
            val settings = settingsDataStore.settingsFlow.first()
            if (activeCount >= settings.maxSimultaneousDownloads) {
                // Keep queued
                downloadDao.updateStatus(id, DownloadStatus.QUEUED)
                return@launch
            }

            launchTask(entity)
        }
    }

    private fun launchTask(entity: DownloadEntity) {
        val id = entity.id
        val task = DownloadTask(
            downloadId = id,
            initialEntity = entity,
            downloadDao = downloadDao,
            segmentDao = segmentDao,
            client = UrlMetadataResolver.client,
            rateLimiter = rateLimiter,
            onCompleted = { completedId ->
                activeTasks.remove(completedId)
                updateSpeedForDownload(completedId, SpeedInfo())
                checkAndProcessQueue()
            },
            onFailed = { failedId, error ->
                activeTasks.remove(failedId)
                updateSpeedForDownload(failedId, SpeedInfo())
                checkAndProcessQueue()
            },
            onProgressNotification = { updatedEntity, speed ->
                updateSpeedForDownload(id, speed)
                DownloadForegroundService.updateNotification(context, updatedEntity, speed)
            }
        )

        activeTasks[id] = task
        DownloadForegroundService.startService(context)
        task.start(scope)
    }

    fun pauseDownload(id: Long) {
        scope.launch {
            val task = activeTasks.remove(id)
            if (task != null) {
                task.pause()
            } else {
                downloadDao.updateStatus(id, DownloadStatus.PAUSED)
            }
            updateSpeedForDownload(id, SpeedInfo())
            checkAndProcessQueue()
        }
    }

    fun cancelDownload(id: Long) {
        scope.launch {
            val task = activeTasks.remove(id)
            if (task != null) {
                task.cancel()
            } else {
                downloadDao.updateStatus(id, DownloadStatus.CANCELLED)
            }
            updateSpeedForDownload(id, SpeedInfo())
            checkAndProcessQueue()
        }
    }

    fun retryDownload(id: Long) {
        scope.launch {
            downloadDao.updateStatus(id, DownloadStatus.QUEUED, null)
            checkAndProcessQueue()
        }
    }

    suspend fun deleteDownload(id: Long, deleteFileFromStorage: Boolean) = withContext(Dispatchers.IO) {
        pauseDownload(id)
        val entity = downloadDao.getDownloadById(id)
        if (entity != null && deleteFileFromStorage) {
            val file = File(entity.destinationPath)
            if (file.exists()) file.delete()
            val part = FilenameUtils.getPartFile(file)
            if (part.exists()) part.delete()
        }
        segmentDao.deleteSegmentsForDownload(id)
        downloadDao.deleteDownloadById(id)
    }

    private fun updateSpeedForDownload(id: Long, speed: SpeedInfo) {
        val current = _speeds.value.toMutableMap()
        current[id] = speed
        _speeds.value = current
    }

    fun checkAndProcessQueue() {
        scope.launch {
            val settings = settingsDataStore.settingsFlow.first()
            val maxConcurrent = settings.maxSimultaneousDownloads
            val currentActive = activeTasks.size

            if (currentActive < maxConcurrent) {
                val needed = maxConcurrent - currentActive
                val queued = downloadDao.getQueuedDownloads()
                for (i in 0 until minOf(needed, queued.size)) {
                    val nextDownload = queued[i]
                    if (!activeTasks.containsKey(nextDownload.id)) {
                        launchTask(nextDownload)
                    }
                }
            }

            if (activeTasks.isEmpty()) {
                DownloadForegroundService.stopService(context)
            }
        }
    }

    fun getSpeedFlow(downloadId: Long): Flow<SpeedInfo> {
        return _speeds.map { speeds ->
            speeds[downloadId] ?: SpeedInfo()
        }
    }

    suspend fun verifyChecksum(
        downloadId: Long,
        expectedHash: String,
        algorithm: String = "SHA-256"
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val entity = downloadDao.getDownloadById(downloadId)
                ?: return@withContext Result.failure(Exception("Download not found"))
            val file = File(entity.destinationPath)
            if (!file.exists()) {
                return@withContext Result.failure(Exception("File not found on storage"))
            }

            val digest = MessageDigest.getInstance(algorithm)
            FileInputStream(file).use { fis ->
                val buffer = ByteArray(64 * 1024)
                var read: Int
                while (fis.read(buffer).also { read = it } != -1) {
                    digest.update(buffer, 0, read)
                }
            }

            val calculatedHash = digest.digest().joinToString("") { "%02x".format(it) }
            val cleanExpected = expectedHash.trim().lowercase()
            val matches = calculatedHash.equals(cleanExpected, ignoreCase = true)

            // Save checksum
            downloadDao.updateDownload(entity.copy(checksum = calculatedHash))

            Result.success(matches)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: DownloadManager? = null

        fun getInstance(context: Context): DownloadManager {
            return INSTANCE ?: synchronized(this) {
                val instance = DownloadManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
