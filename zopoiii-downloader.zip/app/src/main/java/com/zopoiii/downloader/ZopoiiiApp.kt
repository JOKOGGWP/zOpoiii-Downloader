package com.zopoiii.downloader

import android.app.Application

class ZopoiiiApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
