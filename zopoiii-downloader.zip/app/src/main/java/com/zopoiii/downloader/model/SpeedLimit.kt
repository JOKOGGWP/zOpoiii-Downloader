package com.zopoiii.downloader.model

data class SpeedLimit(
    val bytesPerSecond: Long
) {
    val displayName: String
        get() = when (bytesPerSecond) {
            0L -> "Unlimited"
            1_048_576L -> "1 MB/s"
            5_242_880L -> "5 MB/s"
            10_485_760L -> "10 MB/s"
            20_971_520L -> "20 MB/s"
            52_428_800L -> "50 MB/s"
            else -> "${bytesPerSecond / (1024 * 1024)} MB/s"
        }

    companion object {
        val UNLIMITED = SpeedLimit(0L)
        val ONE_MB = SpeedLimit(1_048_576L)
        val FIVE_MB = SpeedLimit(5_242_880L)
        val TEN_MB = SpeedLimit(10_485_760L)
        val TWENTY_MB = SpeedLimit(20_971_520L)
        val FIFTY_MB = SpeedLimit(52_428_800L)

        val PRESETS = listOf(UNLIMITED, ONE_MB, FIVE_MB, TEN_MB, TWENTY_MB, FIFTY_MB)
    }
}
