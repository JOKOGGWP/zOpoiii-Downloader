package com.zopoiii.downloader.model

data class FileMetadata(
    val url: String,
    val resolvedUrl: String,
    val filename: String,
    val totalBytes: Long,
    val isRangeSupported: Boolean,
    val contentType: String?,
    val etag: String?,
    val lastModified: String?,
    val contentDisposition: String?
)
