package com.zopoiii.downloader.engine

import kotlinx.coroutines.delay

class RateLimiter(
    @Volatile var maxBytesPerSecond: Long = 0L // 0 means unlimited
) {
    private var availableTokens: Double = 0.0
    private var lastRefillTimeNanos: Long = System.nanoTime()
    private val lock = Any()

    suspend fun acquire(bytes: Int) {
        val limit = maxBytesPerSecond
        if (limit <= 0L || bytes <= 0) return

        var waitMillis = 0L
        synchronized(lock) {
            val now = System.nanoTime()
            val elapsedSec = (now - lastRefillTimeNanos).toDouble() / 1_000_000_000.0
            lastRefillTimeNanos = now

            // Refill tokens
            availableTokens = (availableTokens + elapsedSec * limit).coerceAtMost(limit.toDouble())

            availableTokens -= bytes
            if (availableTokens < 0) {
                // Calculate delay needed to recover negative tokens
                val deficit = -availableTokens
                waitMillis = ((deficit / limit.toDouble()) * 1000.0).toLong()
            }
        }

        if (waitMillis > 0L) {
            delay(waitMillis.coerceAtMost(1000L))
        }
    }
}
