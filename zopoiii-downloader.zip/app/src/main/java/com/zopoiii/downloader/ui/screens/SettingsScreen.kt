package com.zopoiii.downloader.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.zopoiii.downloader.model.ConnectionMode
import com.zopoiii.downloader.ui.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.appSettings.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Settings",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
        }

        // Connection & Engine Settings
        item {
            SettingsCategoryCard(
                title = "Download Engine",
                icon = Icons.Default.Tune
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        text = "Connection Mode (Per Download)",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )

                    val modes = listOf(
                        ConnectionMode.AUTO,
                        ConnectionMode.ONE,
                        ConnectionMode.TWO,
                        ConnectionMode.FOUR,
                        ConnectionMode.EIGHT,
                        ConnectionMode.SIXTEEN
                    )

                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        modes.forEachIndexed { index, mode ->
                            SegmentedButton(
                                selected = settings.connectionMode == mode,
                                onClick = { viewModel.updateConnectionMode(mode) },
                                shape = SegmentedButtonDefaults.itemShape(index = index, count = modes.size)
                            ) {
                                Text(mode.displayName)
                            }
                        }
                    }

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Max Simultaneous Downloads", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                            Text("Active download queue capacity", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        SingleChoiceSegmentedButtonRow {
                            listOf(1, 2, 3, 4).forEachIndexed { index, count ->
                                SegmentedButton(
                                    selected = settings.maxSimultaneousDownloads == count,
                                    onClick = { viewModel.updateMaxSimultaneousDownloads(count) },
                                    shape = SegmentedButtonDefaults.itemShape(index = index, count = 4)
                                ) {
                                    Text("$count")
                                }
                            }
                        }
                    }
                }
            }
        }

        // Speed Limit Settings
        item {
            SettingsCategoryCard(
                title = "Speed Limiter",
                icon = Icons.Default.Speed
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    val limits = listOf(
                        0L to "Unlimited",
                        1024L * 1024L to "1 MB/s",
                        5L * 1024L * 1024L to "5 MB/s",
                        10L * 1024L * 1024L to "10 MB/s",
                        20L * 1024L * 1024L to "20 MB/s",
                        50L * 1024L * 1024L to "50 MB/s"
                    )

                    Text(
                        text = "Global Download Speed Limit",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )

                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        limits.take(3).forEachIndexed { index, (bytes, label) ->
                            SegmentedButton(
                                selected = settings.speedLimitBytesPerSec == bytes,
                                onClick = { viewModel.updateSpeedLimit(bytes) },
                                shape = SegmentedButtonDefaults.itemShape(index = index, count = 3)
                            ) {
                                Text(label)
                            }
                        }
                    }

                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        limits.drop(3).forEachIndexed { index, (bytes, label) ->
                            SegmentedButton(
                                selected = settings.speedLimitBytesPerSec == bytes,
                                onClick = { viewModel.updateSpeedLimit(bytes) },
                                shape = SegmentedButtonDefaults.itemShape(index = index, count = 3)
                            ) {
                                Text(label)
                            }
                        }
                    }
                }
            }
        }

        // Network & Battery Policies
        item {
            SettingsCategoryCard(
                title = "Network & Battery Policy",
                icon = Icons.Default.NetworkCheck
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SettingToggleRow(
                        title = "Download Only on Wi-Fi",
                        subtitle = "Prevents downloading over cellular data",
                        checked = settings.downloadOnlyWifi,
                        onCheckedChange = { viewModel.updateDownloadOnlyWifi(it) }
                    )

                    HorizontalDivider()

                    SettingToggleRow(
                        title = "Pause When on Mobile Data",
                        subtitle = "Auto-pause active downloads if Wi-Fi disconnects",
                        checked = settings.pauseWhenMobile,
                        onCheckedChange = { viewModel.updatePauseWhenMobile(it) }
                    )

                    HorizontalDivider()

                    SettingToggleRow(
                        title = "Auto Retry on Failure",
                        subtitle = "Exponential backoff: 5s, 10s, 30s, 60s",
                        checked = settings.retryAuto,
                        onCheckedChange = { viewModel.updateRetryAuto(it) }
                    )

                    HorizontalDivider()

                    SettingToggleRow(
                        title = "Continue on Low Battery",
                        subtitle = "Allow engine to download below ${settings.lowBatteryThreshold}%",
                        checked = settings.continueOnLowBattery,
                        onCheckedChange = { viewModel.updateContinueLowBattery(it) }
                    )
                }
            }
        }

        // Storage & Directory Info
        item {
            SettingsCategoryCard(
                title = "Storage & Paths",
                icon = Icons.Default.Folder
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Default Download Location",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Downloads/zOpoiii Downloader/",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Files are saved as .part during download and atomically renamed to original extension when 100% complete.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SettingsCategoryCard(
    title: String,
    icon: ImageVector,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
            content()
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) },
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}
