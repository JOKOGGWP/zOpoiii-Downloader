package com.zopoiii.downloader

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.core.content.ContextCompat
import com.zopoiii.downloader.ui.MainViewModel
import com.zopoiii.downloader.ui.screens.DownloadDetailScreen
import com.zopoiii.downloader.ui.screens.DownloadsScreen
import com.zopoiii.downloader.ui.screens.HomeScreen
import com.zopoiii.downloader.ui.screens.NetworkTestScreen
import com.zopoiii.downloader.ui.screens.SettingsScreen
import com.zopoiii.downloader.ui.theme.ZopoiiiDownloaderTheme

sealed class Screen(val title: String, val icon: ImageVector, val tag: String) {
    data object Home : Screen("Home", Icons.Default.Download, "nav_home")
    data object Downloads : Screen("Downloads", Icons.Default.FormatListBulleted, "nav_downloads")
    data object NetworkTest : Screen("Speed Test", Icons.Default.Speed, "nav_speed_test")
    data object Settings : Screen("Settings", Icons.Default.Settings, "nav_settings")
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            ZopoiiiDownloaderTheme {
                MainApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainApp(viewModel: MainViewModel) {
    val context = LocalContext.current
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Home) }
    var selectedDownloadDetailId by remember { mutableStateOf<Long?>(null) }

    // Request notification permission on Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = {}
    )

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val isGranted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!isGranted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (selectedDownloadDetailId == null) {
                NavigationBar {
                    val navItems = listOf(
                        Screen.Home,
                        Screen.Downloads,
                        Screen.NetworkTest,
                        Screen.Settings
                    )
                    navItems.forEach { screen ->
                        NavigationBarItem(
                            selected = currentScreen == screen,
                            onClick = { currentScreen = screen },
                            icon = { Icon(screen.icon, contentDescription = screen.title) },
                            label = { Text(screen.title) },
                            modifier = Modifier.testTag(screen.tag)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        if (selectedDownloadDetailId != null) {
            DownloadDetailScreen(
                downloadId = selectedDownloadDetailId!!,
                viewModel = viewModel,
                onNavigateBack = { selectedDownloadDetailId = null },
                modifier = Modifier.padding(innerPadding)
            )
        } else {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "screen_transition"
            ) { screen ->
                when (screen) {
                    Screen.Home -> HomeScreen(
                        viewModel = viewModel,
                        onNavigateToDetail = { id -> selectedDownloadDetailId = id },
                        onNavigateToNetworkTest = { currentScreen = Screen.NetworkTest },
                        onNavigateToDownloads = { currentScreen = Screen.Downloads },
                        modifier = Modifier.padding(innerPadding)
                    )
                    Screen.Downloads -> DownloadsScreen(
                        viewModel = viewModel,
                        onNavigateToDetail = { id -> selectedDownloadDetailId = id },
                        modifier = Modifier.padding(innerPadding)
                    )
                    Screen.NetworkTest -> NetworkTestScreen(
                        viewModel = viewModel,
                        onNavigateBack = { currentScreen = Screen.Home },
                        modifier = Modifier.padding(innerPadding)
                    )
                    Screen.Settings -> SettingsScreen(
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}
