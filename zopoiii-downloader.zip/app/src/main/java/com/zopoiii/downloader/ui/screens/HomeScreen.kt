package com.zopoiii.downloader.ui.screens

import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zopoiii.downloader.model.DownloadStatus
import com.zopoiii.downloader.model.SpeedInfo
import com.zopoiii.downloader.ui.MainViewModel
import com.zopoiii.downloader.ui.components.DownloadCard
import com.zopoiii.downloader.ui.theme.StatusActive
import com.zopoiii.downloader.ui.theme.StatusError
import com.zopoiii.downloader.ui.theme.StatusSuccess

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToDetail: (Long) -> Unit,
    onNavigateToNetworkTest: () -> Unit,
    onNavigateToDownloads: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var urlInput by remember { mutableStateOf("") }
    val probeState by viewModel.urlProbeState.collectAsState()
    val allDownloads by viewModel.allDownloads.collectAsState()
    val speeds by viewModel.speeds.collectAsState()
    val networkState by viewModel.networkState.collectAsState()

    val activeDownloads = allDownloads.filter { it.status == DownloadStatus.DOWNLOADING }
    val currentDownload = activeDownloads.firstOrNull() ?: allDownloads.firstOrNull { it.status == DownloadStatus.PAUSED }
    val recentDownloads = allDownloads.take(5)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // App Title Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(26.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "zOpoiii Downloader",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "High-speed multi-connection engine",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // URL Input Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(18.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Paste download link",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )

                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("url_input_field"),
                        placeholder = { Text("https://example.com/files/large-file.zip") },
                        trailingIcon = {
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    if (clipboard.hasPrimaryClip() &&
                                        clipboard.primaryClipDescription?.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN) == true
                                    ) {
                                        val text = clipboard.primaryClip?.getItemAt(0)?.text?.toString()
                                        if (!text.isNullOrBlank()) {
                                            urlInput = text
                                        }
                                    }
                                },
                                modifier = Modifier.testTag("paste_clipboard_button")
                            ) {
                                Icon(Icons.Default.ContentPaste, contentDescription = "Paste from clipboard")
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    Button(
                        onClick = { viewModel.probeUrl(urlInput) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("download_button"),
                        enabled = urlInput.isNotBlank() && !probeState.isLoading,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (probeState.isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.5.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Detecting File...")
                        } else {
                            Icon(Icons.Default.Download, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("DOWNLOAD", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        }
                    }

                    // URL Metadata Probe Preview Result
                    if (probeState.metadata != null) {
                        val meta = probeState.metadata!!
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            ),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = meta.filename,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Size: ${SpeedInfo.formatBytes(meta.totalBytes)}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = if (meta.isRangeSupported) "Multi-Connection: OK" else "Single-Connection",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (meta.isRangeSupported) StatusActive else MaterialTheme.colorScheme.tertiary
                                    )
                                }

                                // Storage sufficiency status
                                Row(
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (probeState.isStorageSufficient) Icons.Default.CheckCircle else Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = if (probeState.isStorageSufficient) StatusSuccess else StatusError,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (probeState.isStorageSufficient) {
                                            "Storage sufficient (${SpeedInfo.formatBytes(probeState.availableStorageBytes)} available)"
                                        } else {
                                            "Not enough storage! (${SpeedInfo.formatBytes(probeState.availableStorageBytes)} free)"
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (probeState.isStorageSufficient) StatusSuccess else StatusError
                                    )
                                }

                                if (!meta.isRangeSupported) {
                                    Text(
                                        text = "Server does not support multi-connection. Using single connection.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Button(
                                    onClick = {
                                        viewModel.startDownloadFromMetadata(meta)
                                        urlInput = ""
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = probeState.isStorageSufficient,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = StatusSuccess
                                    ),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("START DOWNLOAD NOW", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    } else if (probeState.errorMessage != null) {
                        Text(
                            text = probeState.errorMessage!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = StatusError,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }

        // Current Active / Paused Download Card
        if (currentDownload != null) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Current Download",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    DownloadCard(
                        download = currentDownload,
                        speedInfo = speeds[currentDownload.id] ?: SpeedInfo(),
                        onCardClick = { onNavigateToDetail(currentDownload.id) },
                        onPauseClick = { viewModel.pauseDownload(currentDownload.id) },
                        onResumeClick = { viewModel.resumeDownload(currentDownload.id) },
                        onCancelClick = { viewModel.cancelDownload(currentDownload.id) },
                        onRetryClick = { viewModel.retryDownload(currentDownload.id) }
                    )
                }
            }
        }

        // Network Status Widget
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToNetworkTest() },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Wifi,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Network: ${networkState.typeName}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (networkState.isConnected) "Status: Connected" else "Status: Offline",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (networkState.isConnected) StatusSuccess else StatusError
                            )
                        }
                    }

                    FilledTonalButton(
                        onClick = onNavigateToNetworkTest,
                        modifier = Modifier.testTag("test_network_button")
                    ) {
                        Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("TEST NETWORK")
                    }
                }
            }
        }

        // Recent Downloads section
        if (recentDownloads.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Downloads",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "View All (${allDownloads.size})",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.clickable { onNavigateToDownloads() }
                    )
                }
            }

            items(recentDownloads, key = { it.id }) { item ->
                DownloadCard(
                    download = item,
                    speedInfo = speeds[item.id] ?: SpeedInfo(),
                    onCardClick = { onNavigateToDetail(item.id) },
                    onPauseClick = { viewModel.pauseDownload(item.id) },
                    onResumeClick = { viewModel.resumeDownload(item.id) },
                    onCancelClick = { viewModel.cancelDownload(item.id) },
                    onRetryClick = { viewModel.retryDownload(item.id) },
                    onDeleteClick = { viewModel.deleteDownload(item.id, false) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
